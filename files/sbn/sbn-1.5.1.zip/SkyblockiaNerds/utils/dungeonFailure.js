function failHelp(commandName) {
    if(commandName == "tictactoe") {
        ChatLib.chat(`&6Fail Tic Tac Toe Usage: &e/failtic <username> <rank>`)
    } else if(commandName == "blaze") {
        ChatLib.chat(`&6Fail Blaze Usage: &e/failblaze <username> <rank>`)
    } else if(commandName == "riddle") {
        ChatLib.chat(`&6Fail Riddle Usage: &e/failriddle <username> <rank> <Name of the Man>`)
    } else {
        ChatLib.chat(`&c&lDungeonFailure Commands:\n &e-/failtic: Fail Tic Tac Toe! (/failhelp tictactoe)\n &e-/failblaze: Fail Blaze! (/failhelp blaze)\n &e-/failriddle: Fail the Riddle Puzzle! (/failhelp riddle)`)
    }
}
function failTic(name, rank) {
    if(!name) {
        ChatLib.chat(`&cHey! Make sure to include a username!`)
    } else if(!rank) {
        ChatLib.chat(`&cHey! Make sure to include a rank!`)
    } else {
        switch(rank) {
            case "non":
                ChatLib.chat(`&c&lPUZZLE FAIL! &7${name} &elost Tic Tac Toe! &4Y&ci&6k&ee&as&2!`)
                break
            case "vip":
                ChatLib.chat(`&c&lPUZZLE FAIL! &a${name} &elost Tic Tac Toe! &4Y&ci&6k&ee&as&2!`)
                break
            case "mvp":
                ChatLib.chat(`&c&lPUZZLE FAIL! &b${name} &elost Tic Tac Toe! &4Y&ci&6k&ee&as&2!`)
                break 
            case "mvp++":
                ChatLib.chat(`&c&lPUZZLE FAIL! &6${name} &elost Tic Tac Toe! &4Y&ci&6k&ee&as&2!`)
                break 
            default:
                ChatLib.chat(`&cHey! You can only Use &7"non"&c, &a"vip"&c, &b"mvp"&c, or &6"mvp++"&c as a rank!`)
                break
        }
    }
}
function failBlaze(name, rank) {
    if(!name) {
        ChatLib.chat(`&cHey! Make sure to include a username!`)
    } else if(!rank) {
        ChatLib.chat(`&cHey! Make sure to include a rank!`)
    } else {
        switch(rank) {
            case "non":
                ChatLib.chat(`&c&lPUZZLE FAIL! &7${name} &ekilled a Blaze in the wrong order! &4Y&ci&6k&ee&as&2!`)
                break
            case "vip":
                ChatLib.chat(`&c&lPUZZLE FAIL! &a${name} &ekilled a Blaze in the wrong order! &4Y&ci&6k&ee&as&2!`)
                break
            case "mvp":
                ChatLib.chat(`&c&lPUZZLE FAIL! &b${name} &ekilled a Blaze in the wrong order! &4Y&ci&6k&ee&as&2!`)
                break 
            case "mvp++":
                ChatLib.chat(`&c&lPUZZLE FAIL! &6${name} &ekilled a Blaze in the wrong order! &4Y&ci&6k&ee&as&2!`)
                break 
            default:
                ChatLib.chat(`&cHey! You can only Use &7"non"&c, &a"vip"&c, &b"mvp"&c, or &6"mvp++"&c as a rank!`)
                break
        }
    }
}
function failRiddle(name, rank, riddleName) {
    if(!name) {
        ChatLib.chat(`&cHey! Make sure to include a username!`)
    } else if(!rank) {
        ChatLib.chat(`&cHey! Make sure to include a rank!`)
    } else if(!riddleName) {
        ChatLib.chat(`&cHey! Make sure to include the name of the Riddle Person!`)
    } else {
        switch(rank) {
            case "non":
                ChatLib.chat(`&c&lPUZZLE FAIL! &7${name} &ewas fooled by &c${riddleName}&e! &4Y&ci&6k&ee&as&2!`)
                break
            case "vip":
                ChatLib.chat(`&c&lPUZZLE FAIL! &a${name} &ewas fooled by &c${riddleName}&e!&4Y&ci&6k&ee&as&2!`)
                break
            case "mvp":
                ChatLib.chat(`&c&lPUZZLE FAIL! &b${name} &ewas fooled by &c${riddleName}&e! &4Y&ci&6k&ee&as&2!`)
                break 
            case "mvp++":
                ChatLib.chat(`&c&lPUZZLE FAIL! &6${name} &ewas fooled by &c${riddleName}&e! &4Y&ci&6k&ee&as&2!`)
                break 
            default:
                ChatLib.chat(`&cHey! You can only Use &7"non"&c, &a"vip"&c, &b"mvp"&c, or &6"mvp++"&c as a rank!`)
                break
    }
}
}

//DungeonFailure Commands
register("command", (helpWith) => {
    failHelp(helpWith)
}).setName("failhelp")

register("command", (username, userRank) => {
    failTic(username, userRank)
}).setName("failtic")

register("command", (username, userRank) => {
    failBlaze(username, userRank)
}).setName("failblaze")

register("command", (username, userRank, riddleName) => {
    failRiddle(username, userRank, riddleName)
}).setName("failriddle")