import { settings } from "../settings"
import { inSkyblock } from "./inSkyblock"

//Custom PMs
register("chat", (user, message, event) => {
    if(!settings.getSetting("Chat Customizer", "&5Custom PMs")) return
    cancel(event)
    if(message == "&r&d&lBoop!&r") message = message
    else message = ChatLib.removeFormatting(message)
    ChatLib.chat(`${settings.getSetting("Chat Customizer", "&dFrom &fMessage")} ${user}: ${message}`)
}).setCriteria("&dFrom ${user}: ${message}")

register("chat", (user, message, event) => {
    if(!settings.getSetting("Chat Customizer", "&5Custom PMs")) return
    cancel(event)
    if(message == "&r&d&lBoop!&r") message = message
    else message = ChatLib.removeFormatting(message)
    ChatLib.chat(`${settings.getSetting("Chat Customizer", "&dTo &fMessage")} ${user}: ${message}`)
}).setCriteria("&dTo ${user}: ${message}")

//Custom Join/Leave Messages


//Guild
register("chat", (joinPerson, event) => {
    if(!settings.getSetting("Chat Customizer", "&aCustom Join/Leave Messages")) return
    cancel(event)
    ChatLib.chat(`${settings.getSetting("Chat Customizer", "&2Guild")} ${joinPerson} &ejoined.`)
}).setCriteria("&2Guild > ${joinPerson} &r&ejoined.&r").setParameter("<c>")
register("chat", (joinPerson, event) => {
    if(!settings.getSetting("Chat Customizer", "&aCustom Join/Leave Messages")) return
    cancel(event)
    ChatLib.chat(`${settings.getSetting("Chat Customizer", "&2Guild")} ${joinPerson} &eleft.`)
}).setCriteria("&2Guild > ${joinPerson} &r&eleft.&r").setParameter("<c>")

//Friends
register("chat", (joinPerson, event) => {
    if(!settings.getSetting("Chat Customizer", "&aCustom Join/Leave Messages")) return
    cancel(event)
    ChatLib.chat(`${settings.getSetting("Chat Customizer", "&aFriends")} ${joinPerson} &ejoined.`)
}).setCriteria("&aFriend > ${joinPerson} &r&ejoined.&r").setParameter("<c>")
register("chat", (joinPerson, event) => {
    if(!settings.getSetting("Chat Customizer", "&aCustom Join/Leave Messages")) return
    cancel(event)
    ChatLib.chat(`${settings.getSetting("Chat Customizer", "&aFriends")} ${joinPerson} &eleft.`)
}).setCriteria("&aFriend > ${joinPerson} &r&eleft.&r").setParameter("<c>")

//Chat Prefixes

//Guild
register("chat", (person, message, event) => {
    if(!settings.getSetting("Chat Customizer", "&3Custom Chat Prefixes")) return
    cancel(event)
    message = ChatLib.removeFormatting(message)
    ChatLib.chat(`${settings.getSetting("Chat Customizer", "&2Guild Chat Prefix")} ${person}: ${message}`)
}).setCriteria("&r&2Guild > ${person}: ${message}").setParameter("<c>")
//Party
register("chat", (person, message, event) => {
    if(!settings.getSetting("Chat Customizer", "&3Custom Chat Prefixes")) return
    cancel(event)
    message = ChatLib.removeFormatting(message)
    ChatLib.chat(`${settings.getSetting("Chat Customizer", "&9Party Chat Prefix")} ${person}: ${message}`)
}).setCriteria("&r&9Party &8> ${person}: ${message}").setParameter("<c>")
//Coop LMAO
register("chat", (person, message, event) => {
    if(!inSkyblock() && settings.getSetting("Chat", "&bHide CoopChat Outside of Skyblock")) return cancel(event)
    if(!settings.getSetting("Chat Customizer", "&3Custom Chat Prefixes")) return
    cancel(event)
    message = ChatLib.removeFormatting(message)
    ChatLib.chat(`${settings.getSetting("Chat Customizer", "&bCoop-Chat Prefix")} ${person}: ${message}`)
}).setCriteria("&r&bCo-op > ${person}: ${message}").setParameter("<c>")


register("chat", (user, event) => {
    if(settings.getSetting("Chat", "&9Hide \"&6joined the lobby!&9\" messages")) cancel(event)
}).setCriteria("${user}&6 joined the lobby!&r").setParameter("<c>")
register("chat", (user, stars, event) => {
    if(settings.getSetting("Chat", "&eHide &bMystery Box &emessages")) cancel(event)
}).setCriteria("${user} &r&ffound a ${stars} &r&bMystery Box&r&f!&r").setParameter("<c>")


register("chat", (event) => {
    if(settings.getSetting("Chat", "&6Prevent \"&cYou cannot leave this area!&6\" messages")) {
        cancel(event)
    }
}).setCriteria("&r&cYou are not allowed to leave this area!&r").setParameter("<c>")

register("chat", (coopMate, event) => {
    if(!settings.getSetting("Chat", "&aAntiSBJoin")) return
    cancel(event)
}).setCriteria('&b${coopMate} joined SkyBlock.&r').setParameter("<c>")

register("chat", (coopMate, event) => {
    if(!settings.getSetting("Chat", "&aAntiSBJoin")) return
    cancel(event)
}).setCriteria('&b${coopMate} left SkyBlock.&r').setParameter("<c>")

//Watchdog Announcements
register("chat", (message, event) => {
    if(settings.getSetting("Chat", "&cHide Watchdog Announcements")) cancel(event)
}).setCriteria("&4[WATCHDOG ANNOUNCEMENT]&r").setParameter("<c>")
register("chat", (message, event) => {
    if(settings.getSetting("Chat", "&cHide Watchdog Announcements")) cancel(event)
}).setCriteria("&fWatchdog has banned &r&c&l25,939&r&f players in the last 7 days.&r").setParameter("<c>")
register("chat", (message, event) => {
    if(settings.getSetting("Chat", "&cHide Watchdog Announcements")) cancel(event)
}).setCriteria("&fStaff have banned an additional &r&c&l13,154&r&f in the last 7 days.&r").setParameter("<c>")
register("chat", (message, event) => {
    if(settings.getSetting("Chat", "&cHide Watchdog Announcements")) cancel(event)
}).setCriteria("&cBlacklisted modifications are a bannable offense!&r").setParameter("<c>")