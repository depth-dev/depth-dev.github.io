import PVObject from "PersistentData"

const pvObject = new PVObject("SkyblockiaNerds", {
    sbnclipboard: "Your clipboard will go here!"
})

const Toolkit = Java.type("java.awt.Toolkit")
const StringSelection = Java.type("java.awt.datatransfer.StringSelection")

copyToClipboard = text => {
    clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
    output = new StringSelection(text);
    
    try {
      clipboard.setContents(output, output);
      print("Copied text to clipboard.")
    } catch (err) {
      print(err)
    }
}

function copytoSBNClipboard(...args) {
    if(!args[0]) return ChatLib.chat(`&d&lSkyblockiaNerds&b: Please submit a valid function! Valid functions: &aCopy, Paste, List`)
    switch(args[0]) {
        case "list":
            ChatLib.chat(`&d&lSkyblockiaNerds&b: Your SBN Clipboard is &a${pvObject.sbnclipboard}&b!`)
            break 
        case "copy":
            let whatToCopy = args.slice(1).join(" ")
            if(!whatToCopy) return ChatLib.chat(`&d&lSkyblockiaNerds&b: Please provide something to copy!`)
            pvObject.sbnclipboard = whatToCopy
            ChatLib.chat(`&d&lSkyblockiaNerds&b: Copied text to your SBN Clipboard! Do &a/sbnclipboard paste &bto copy it to your computer clipboard!`)
            break 
        case "paste":
            copyToClipboard(pvObject.sbnclipboard)
            ChatLib.chat(`&d&lSkyblockiaNerds&b: Copied your SBN Clipboard to your computer clipboard!`)
            break 
        default:
            ChatLib.chat(`&d&lSkyblockiaNerds&b: Please submit a valid function! Valid functions: &aCopy, Paste, List`)
            break
        }
}
register("command", (...args) => {
    copytoSBNClipboard(...args)
}).setName("sbnclipboard")

export { pvObject, copytoSBNClipboard }