import { settings } from "../settings"
import { inSkyblock } from "./inSkyblock"
import { onIsland, inDungeons } from "./locationChecker"
import request from "request/index"

const getjson = function(url) {
    return request({
        url: url,
        headers: {
            'User-Agent': 'Mozilla/5.0 (ChatTriggers)'
        },
        json: true
    });
}


let premium = false
register("worldLoad", () => {
    getjson("https://misterdepth.github.io/api/sbn.json").then(response =>{
        let premUsers = response["premiumUsers"]
        premUsers.forEach(user => {
            if(Player.getUUID().toString().replace(/-/ig, "") == user) {
                premium = true
            }
        })
    })
})

register("chat", (visiter, event) => {
    if(!settings.getSetting("Alerts", "&aIsland Visitor Alerts")) return
    ChatLib.chat(`&d&lSkyblockiaNerds: &b${visiter} &bjoined your island!`)
    World.playSound('random.orb', 2, 1)
    cancel(event)
}).setCriteria('&b[SkyBlock] &r${visiter} &r&eis visiting &r&aYour Island&r&e!&r').setParameter('<c>')

register("chat", (bidder, coins, item) => {
    if(settings.getSetting("Alerts", "&eAuction Bid Alerts")) {
        World.playSound('random.orb', 2, 1)
    }
}).setCriteria('&6[Auction] ${bidder} &ebought ${item} &efor &6${coins} coins &lCLICK&r').setParameter('<c>')

register("chat", (bidder, coins, item) => {
    if(settings.getSetting("Alerts", "&eAuction Bid Alerts")) {
        World.playSound("random.orb", 2, 1)
    }
}).setCriteria("&6[Auction] ${bidder} &ebid &6${coins} coins &eon ${item} &e&lCLICK&r").setParameter("<c>")

const purseRegex = /Purse: (.+)/
const piggyRegex = /Piggy: (.+)/
register("worldLoad", () => {
    if(settings.getSetting("Alerts", "&6Large Amount of Coins Alert")) {
        let am 
        setTimeout(() => {
            if(inSkyblock() && !onIsland()) {
                Scoreboard.getLines(false).forEach(line => {
                    line = ChatLib.removeFormatting(line)
                    if(line.match(purseRegex) || line.match(piggyRegex)) {
                        am = line.replace("Piggy: ", "").replace("Purse: ", "").replace(/\(+(.+)\)/g, "").replace(/\(/g, "").replace(/\)/g, "").replace(" ", "")
                        let uAM = am.replace(/,/g, "")
                        if(parseFloat(uAM) >= 20000) {
                            World.playSound("random.orb", 2, 1)
                            ChatLib.chat(`&d&lSkyblockiaNerds&b: You have a large amount of coins on you(&6${am}&b)! Be careful!`)
                        }
                    }
                })
            }
        }, 1000)
    }
})

register("tick", () => {
    if(settings.getSetting("Alerts", "&4Low Health Alert &6[BETA]") && premium) {
        if(Player.getHP() <= 8) {
            Client.showTitle("&cLow Health", "", 0, 3, 0)
        }
    }
})

register("chat", (ability, event) => {
    if(settings.getSetting("Alerts", "&bAbility Ready Alerts")) Client.showTitle(`&6${ability} &ais ready!`, "", 0, 80, 0)
}).setCriteria("&r&6${ability} &r&ais now available!&r").setParameter("<c>")

register("chat", (_class, ability, event) => {
    if(settings.getSetting("Alerts", "&bAbility Ready Alerts")) Client.showTitle("", `&aUltimate &6${ability} &ais ready!`, 0, 80, 0)
}).setCriteria("&r&aYour ${_class} &r&e&lULTIMATE&r&a &r&6${ability} &r&ais now available!&r").setParameter("<c>")


register("chat", (megaID) => {
    alertMode = settings.getSetting("Alerts", "&cMega-Alert Mode")
    if(!settings.getSetting("Alerts", "&cMega-Alerts")) return
    if(!inSkyblock()) return
    switch(alertMode) {
        case "Title (Big)":
            setTimeout(() => {
                Client.showTitle("&bYou are entering a mega!", "", 0, 30, 0)
                World.playSound('random.orb', 2, 1)
             }, 1500)
            break
        case "Title (Small)":
            setTimeout(() => {
                Client.showTitle("", "&bYou are entering a mega!", 0, 30, 0)
                World.playSound('random.orb', 2, 1)
             }, 1500)
            break
        case "Chat":
            setTimeout(() => {
                ChatLib.chat('&d&lSkyblockiaNerds: &bYou are entering a mega! Be careful!')
                World.playSound('random.orb', 2, 1)
             }, 1500)
            break
        default:
            break
    }
}).setCriteria('&7Sending to server mega${megaID}...&r').setParameter('<c>')