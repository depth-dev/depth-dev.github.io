function onIsland() {
    if(!(Scoreboard.getTitle().trim() != "" && Scoreboard.getLines().length > 0)) {
        return;
    }
    for(let i = 0; i < Scoreboard.getLines().length; i++) {
        let line = Scoreboard.getLines()[i]
        if(line.getName().includes('Your'))
            return true
    }
    return false
}

function inPark() {
    if(!(Scoreboard.getTitle().trim() != "" && Scoreboard.getLines().length > 0)) {
        return;
    }
    for(let i = 0; i < Scoreboard.getLines().length; i++) {
        let line = Scoreboard.getLines()[i]
        if(line.getName().includes('Birch Par'))
            return true
    }
    return false
}

function inComCen() {
    if(!(Scoreboard.getTitle().trim() != "" && Scoreboard.getLines().length > 0)) {
        return;
    }
    for(let i = 0; i < Scoreboard.getLines().length; i++) {
        let line = Scoreboard.getLines()[i]
        if(line.getName().includes('Community'))
            return true
    }
    return false
}
//Thanks Vals
function inDungeons() {
    if(!(Scoreboard.getTitle().trim() != "" && Scoreboard.getLines().length > 0)) {
        return;
    }
    for(let i = 0; i < Scoreboard.getLines().length; i++) {
        let line = Scoreboard.getLines()[i]
        if(line.getName().includes('§cThe Cata') && line.getName().includes('mbs §8('))
            return true
    }
    return false
}

export { onIsland, inPark, inComCen, inDungeons }