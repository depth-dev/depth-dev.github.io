function openWarpMenu() {
    new Message(
        new TextComponent("&b&m&l------------&d&lSkyblockiaNerds Warps&b&m&l-----------------\n"),
        new TextComponent(`&a≈ Warp to &bHub\n`).setClick("run_command", "/warp hub").setHover("show_text", "&aWarp to &bHub"),
        new TextComponent(`&a≈ Warp to &9Island\n`).setClick("run_command", "/warp home").setHover("show_text", "&aWarp to &bIsland"),
        new TextComponent(`&a≈ Warp to &5End\n`).setClick("run_command", "/warp end").setHover("show_text", "&aWarp to &4End Island"),
        new TextComponent(`&a≈ Warp to &cDungeon Hub\n`).setClick("run_command", "/warp dungeon_hub").setHover("show_text", "&aWarp to &cDungeon Hub"),
        new TextComponent(`&a≈ Warp to &4Blazing Fortress\n`).setClick("run_command", "/warp nether").setHover("show_text", "&aWarp to &4Blazing Fortress"),
        new TextComponent(`&a≈ Warp to &2The Park\n`).setClick("run_command", "/warp park").setHover("show_text", "&aWarp to &2The Park"),
        new TextComponent(`&a≈ Warp to &7Howling Cave\n`).setClick("run_command", "/warp howl").setHover("show_text", "&aWarp to &7Howling Cave"),
        new TextComponent("&b&m" + ChatLib.getChatBreak("-"))
    ).chat()
}

export { openWarpMenu }