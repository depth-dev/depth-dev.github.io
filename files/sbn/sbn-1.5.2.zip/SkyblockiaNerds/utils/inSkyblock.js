function inSkyblock() {
    if(ChatLib.removeFormatting(Scoreboard.getTitle()).includes("SKYBLOCK") && Server.getIP().includes("hypixel.net")) {
        return true
    } else {
        return false
    }
}

export { inSkyblock }