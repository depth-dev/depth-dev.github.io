import { settings } from "../settings"

let playerX
let playerY
let playerZ
let centerToggled

register("tick", () => {
    playerX = Player.getX().toFixed(settings.getSetting("Displays", "&bCoordinate Decimal Count"))
    playerY = Player.getY().toFixed(settings.getSetting("Displays", "&bCoordinate Decimal Count"))
    playerZ = Player.getZ().toFixed(settings.getSetting("Displays", "&bCoordinate Decimal Count"))
})

register("renderOverlay", renderOverlay)
let theColor = Renderer.color(0, 0, 0, 50)
function renderOverlay() {
    let width = Renderer.screen.getWidth()
    let height = Renderer.screen.getHeight()
    if(settings.getSetting("Displays", "&2Dark Background Behind Coordinates") && settings.getSetting("Displays", "&dShow Coordinates on Screen")) {
        let coordArray = [
            Renderer.getStringWidth(Player.getX().toString()),
            Renderer.getStringWidth(Player.getY().toString()),
            Renderer.getStringWidth(Player.getZ().toString())
        ]
        let totalWidth = Math.max.apply(Math, coordArray)
        if(settings.getSetting("Displays", "&aAdjust Box Based on Coordinates Length &6[BETA]")) equationThing = ((totalWidth / 2) - 40)
        else equationThing = 0
        Renderer.drawRect(theColor, 0, 0, 50 + settings.getSetting("Displays", "&bCoordinate Decimal Count") * 5 + 5 + equationThing, 40)
    }
    if(settings.getSetting("Displays", "&dShow Coordinates on Screen")) {
        Renderer.drawStringWithShadow(`&dX &7> &b${playerX}`, 5, 5)
        Renderer.drawStringWithShadow(`&dY &7> &b${playerY}`, 5, 15)
        Renderer.drawStringWithShadow(`&dZ &7> &b${playerZ}`, 5, 25)
    }
}
