import { settings } from "../settings"
let imageSelec = new Image("Pepega", "https://www.streamscheme.com/wp-content/uploads/2020/04/pepega.png")

register("tick", () => {
    if(settings.getSetting("Emotes", "&2Emote Display")) {
    switch(settings.getSetting("Emotes", "&2Emote Selected")) {
        case "Pepega":
            imageSelec = new Image("Pepega", "https://www.streamscheme.com/wp-content/uploads/2020/04/pepega.png")
            break
        case "PogChamp":
            imageSelec = new Image("PogChamp", "https://www.streamscheme.com/wp-content/uploads/2020/04/Pogchamp.png")
            break 
        default:
            imageSelec = new Image("Pepega", "https://www.streamscheme.com/wp-content/uploads/2020/04/pepega.png")
            break
    }
}
})

register("renderOverlay", () => {
    let width = Renderer.screen.getWidth()
    let height = Renderer.screen.getHeight()
    if(settings.getSetting("Emotes", "&2Emote Display")) {
        imageSelec.draw(width / 1000 * settings.getSetting("Emotes", "&aEmote Display X"), height / 1000 * settings.getSetting("Emotes", "&aEmote Display Y"), settings.getSetting("Emotes", "&aEmote Display Size"), settings.getSetting("Emotes", "&aEmote Display Size"))
    }
}) 