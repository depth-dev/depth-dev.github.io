/// <reference types="../CTAutocomplete" />
/// <reference lib="es2015" />

//Imports are Super Cool
import { Setting, SettingsObject } from "SettingsManager/SettingsManager"
import { settings } from "./settings"
import request from "request/index";
import PVObject from "PersistentData"
import { inSkyblock } from "./utils/inSkyblock"
import { onIsland, inPark, inDungeons } from "./utils/locationChecker"
import { openWarpMenu } from "./utils/warpMenu"
import NVPData from "NVPData"
const prefix = "&d&lSkyblockiaNerds"
const currentVersion = "1.5.0"
//Okay so Premium is technically free for now so uh have fun I guess (to get it set the variable to true)
const premium = false
const NVP = new NVPData("SkyblockiaNerds")
//External Files

//Clipboard
require("./utils/clipboard")
//Chat Customizer
require('./utils/chatUtils')
//Dumb Emotes
require('./utils/emotes')
//Player Coordinates + Info
require('./utils/playerHUD')
//DungonFailure Commands
require('./utils/dungeonFailure')
//Alerts
require("./utils/alerts")

//Defining Functions is Super Cool
const getjson = function(url) {
    return request({
        url: url,
        headers: {
            'User-Agent': 'Mozilla/5.0 (ChatTriggers)'
        },
        json: true
    });
}
copyToClipboard = text => {
    clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
    output = new StringSelection(text);
    
    try {
      clipboard.setContents(output, output);
      print("Copied text to clipboard.")
    } catch (err) {
      print(err)
    }
}
function resetSettings() {
    settings.reset()
    settings.load()
}
function advertise() {
    const chance = Math.floor(Math.random()*20+1)
    if(chance == 1 && !premium) {
        let types = [
            "hyalert",
            "playerdata",
            "elemento"
        ]
        let type = Math.floor(Math.random()*types.length)
        ChatLib.chat(new TextComponent(`&d&lSkyblockiaNerds&b: Thank you for using this module! &6Click here to learn more about a sponsor of SBN!`).setClick("run_command", `/sbnsponsor ${types[type]}`).setHover("show_text", "&6Click here to find out more about a SBN Sponsor!"))
    }
}


//Settings
Setting.register(settings);

register("command", () => {
    resetSettings()
    ChatLib.chat(`&d&lSkyblockiaNerds&b: Your settings have been reset!`)
}).setName("resetsbnsettings")

register("chat", (message, event) => {
    resetSettings()
}).setCriteria("&d&lSkyblockiaNerds&b: Reset your settings!").setParameter("<c>")


//Keybinds
const sbMenuKeybind = new KeyBind("Open SBMenu", Keyboard.KEY_NONE, "SkyblockiaNerds")
const wardrobeKeybind = new KeyBind("Open Wardrobe", Keyboard.KEY_NONE, "SkyblockiaNerds")
const craftKeybind = new KeyBind("Open Crafting Menu", Keyboard.KEY_NONE, "SkyblockiaNerds")
const ecKeybind = new KeyBind("Open EnderChest", Keyboard.KEY_NONE, "SkyblockiaNerds")
const settingsKeybind = new KeyBind("Open Settings GUI", Keyboard.KEY_NONE, "SkyblockiaNerds")
const warpMenuKeybind = new KeyBind("Warp Menu", Keyboard.KEY_NONE, "SkyblockiaNerds")


register("tick", () => {
    if(settingsKeybind.isPressed()) settings.open()
    if(warpMenuKeybind.isPressed()) openWarpMenu()
    if(!inSkyblock()) return 
    if(sbMenuKeybind.isPressed()) ChatLib.command("sbmenu")
    if(wardrobeKeybind.isPressed()) ChatLib.command("wardrobe")
    if(craftKeybind.isPressed()) ChatLib.command("craft")
    if(ecKeybind.isPressed()) ChatLib.command("enderchest")
})




//The other garbage
const Toolkit = Java.type("java.awt.Toolkit")
const StringSelection = Java.type("java.awt.datatransfer.StringSelection")

register("command", (pageNum) => {
    if(!pageNum) pageNum = "1"
    switch(pageNum) {
        case "1":
            advertise()
            ChatLib.chat('&b&m&l------------&d&lSkyblockiaNerds Commands&b&m&l---------------')
            new Message(
                new TextComponent('&b- /dh &a(Warp to dungeon hub)\n').setClick("suggest_command", "/dh"),
                new TextComponent('&b- /recipe &a(Shortcut for /viewrecipe.)\n').setClick("suggest_command", "/recipe SKYBLOCK_ITEM_ID"),
                new TextComponent('&b- /crd &a(Crazy Rare Drop!)\n').setClick("suggest_command", "/crd rarity item"),
                new TextComponent('&b- /sbnsettings &a(Shows you your settings!)\n').setClick("suggest_command", "/sbnsettings"),
                new TextComponent('&b- /minions &a(Shows you your crafted minions!)\n').setClick("suggest_command", "/minions"),
                new TextComponent('&b- /viewplancke &a(Plancke link for user!)\n').setClick("suggest_command", "/viewplancke username"),
                new TextComponent('&2Page 1/3')
            ).chat()
            ChatLib.chat("&b&m" + ChatLib.getChatBreak("-"))
            break
        case "2":
            advertise()
            ChatLib.chat('&b&m&l------------&d&lSkyblockiaNerds Commands&b&m&l---------------')
            new Message(
                new TextComponent('&b- /failhelp &a(Shows you commands for the Dungeon Failures!)\n').setClick("suggest_command", "/failhelp command/nothing"),
                new TextComponent('&b- /warpmenu &a(Get some easy-click warp commands!)\n').setClick("suggest_command", "/warpmenu"),
                new TextComponent('&b- /rewarp &a(Swap a warp location quickly!)\n').setClick("suggest_command", "/rewarp location"),
                new TextComponent('&b- /getuuid &a(Get the UUID of a given player!)\n').setClick("suggest_command", "/getuuid username"),
                new TextComponent('&b- /sbnerds info &a(Info of the module!)\n').setClick("suggest_command", "/sbnerds info"),
                new TextComponent('&b- /sbnclipboard &a(Have a second clipboard!)\n').setClick("suggest_command", "/sbnclipboard list/copy/paste"),
                new TextComponent('&2Page 2/3')
            ).chat()
            ChatLib.chat("&b&m" + ChatLib.getChatBreak("-"))
            break 
        case "3":
            advertise()
            ChatLib.chat('&b&m&l------------&d&lSkyblockiaNerds Commands&b&m&l---------------')
            new Message(
                new TextComponent('&b- /shortcut &a(Uses the shortcut menu!)\n').setClick("suggest_command", "/shortcut SHORTCUT_NUMBER"),
                new TextComponent('&2Page 3/3')
            ).chat()
            ChatLib.chat("&b&m" + ChatLib.getChatBreak("-"))
            break 
        case "config":
        case "settings":
            settings.open()
            break
        case "downloads":
            getjson("https://www.chattriggers.com/api/modules/SkyblockiaNerds").then(response => {
                let downloads = response["downloads"]
                ChatLib.chat(new TextComponent(`&d&lSkyblockiaNerds&b: This module has &a&l${downloads} &bdownloads!`)
                .setHover("show_text", `&d&lStats:\n&bDownloads: &a${downloads}\n&bCurrent Version: &a${currentVersion}\n&bFounded: &a8/30/2020\n\n&bRun on NVP ${NVP.version()}`))
            }).catch(err => {
                print(err)
                ChatLib.chat(`&d&lSkyblockiaNerds&b: An error occurred when fetching the downloads of this module!`)
            })
            break
        case "info":
            ChatLib.chat('&b&m&l-------------&d&lSkyblockiaNerds Info&b&m------------------\n' +
            '&bWhat is SkyblockiaNerds?\n' +
            '&a -SkyblockiaNerds is a Skyblock + General Hypixel Utility Module for ChatTriggers.\n' +
            '&a -While is is meant for Skyblock, some features (such as Coordinates) can be used anywhere!\n' +
            '&bWhat features does it have?\n' +
            '&a -It has Alerts for when you go into a mega, when you have a large amount of coins in your purse, and even more!\n' +
            '&a -There are also Non-SB Related Utilities (despite the name being SkyblockiaNerds) including coordinates and more!\n' +
            '&bDo I have the latest version?\n' +
            '&a -All public releases made will be auto-updated with chattriggers, and Betas are private (meaning they are only given to some people!)')
            ChatLib.chat("&b&m&l-----------------------------------------------")
            break 
        case "reset":
            ChatLib.chat(new TextComponent(`&d&lSkyblockiaNerds&b: Click here to reset your settings!`).setClick("run_command", "/resetsbnsettings").setHover("show_text", "&6Be careful!"))
            break
        default:
            ChatLib.chat('&d&lSkyblockiaNerds: &bInvalid number! Please insert a page (1-3)')
            break
}
}).setName('sbnerds')

register("command", () => {
    if(inSkyblock()) {
        ChatLib.command('warp dungeon_hub')
        ChatLib.chat(`&d&lSkyblockiaNerds: &6Warped you to dungeon hub!`)
        World.playSound('mob.endermen.portal', 2, 1)
    } else {
        ChatLib.chat('&cYou can only use this in SkyBlock!')
    }
}).setName('dh')

register("command", (...args) => {
    const itemThing = args.slice(1).join(' ')
    if(!itemThing) {
        ChatLib.chat(`&cPlease provide an item and a rarity! (Example: /crd epic Overflux Capacitor)`)
    } else {
        switch(args[0]) {
            case "common":
                ChatLib.chat(`&d&lCRAZY RARE DROP! &7(&f${itemThing}&7) &b(+98% Magic Find)`)
                break
            case "uncommon":
                ChatLib.chat(`&d&lCRAZY RARE DROP! &7(&a${itemThing}&7) &b(+98% Magic Find)`)
                break 
            case "rare":
                ChatLib.chat(`&d&lCRAZY RARE DROP! &7(&9${itemThing}&7) &b(+98% Magic Find)`)
                break
            case "epic":
                ChatLib.chat(`&d&lCRAZY RARE DROP! &7(&5${itemThing}&7) &b(+98% Magic Find)`)
                break 
            case "legendary":
                ChatLib.chat(`&d&lCRAZY RARE DROP! &7(&6${itemThing}&7) &b(+98% Magic Find)`)
                break 
            case "mythic":
                ChatLib.chat(`&d&lCRAZY RARE DROP! &7(&d${itemThing}&7) &b(+98% Magic Find)`)
                break
            default:
                ChatLib.chat(`&cYou can only have &fcommon&c, &auncommon&c, &9rare&c, &5epic&c, &6legendary&c, or &dmythic&c as a rarity!`)
                break
        }
     }
}).setName('crd')

register("command", (name) => {
    if(!name) return ChatLib.chat('&cPlease input a username!')
    getjson(`https://api.mojang.com/users/profiles/minecraft/${name}`).then(response => {
        var uuid = response["id"];
            ChatLib.chat(new TextComponent(`&d&lSkyblockiaNerds: &a&l${name}'s &bPlancke`).setClick("open_url", `https://plancke.io/hypixel/player/stats/${name}`).setHover("show_text", "&bClick here for the plancke of this user!"))
    }).catch(error => {
        print(error)
        ChatLib.chat(`&d&lSkyblockiaNerds: &bInvalid IGN &a&l${name} &bor something else went wrong!`)
    })
}).setName('viewplancke')

register("command", (username) => {
    if(!username) {
        let playerUUID = Player.getUUID().toString().replace(/-/ig, "")
        ChatLib.chat(new TextComponent(`&d&lSkyblockiaNerds&b: Click to copy your UUID!`).setClick("run_command", `/sbncopyuuid ${playerUUID}`).setHover("show_text", "&6Click to copy your UUID!"))

    } else {
        getjson(`https://api.mojang.com/users/profiles/minecraft/${username}`).then(response => {
        var uuid = response["id"];
            ChatLib.chat(new TextComponent(`&d&lSkyblockiaNerds&b: Click here to copy ${username}&b's UUID!`).setClick("run_command", `/sbncopyuuid ${uuid}`).setHover("show_text", `&6Click to copy ${username}'s UUID!`))
    }).catch(error => {
        print(error)
        ChatLib.chat(`&d&lSkyblockiaNerds: &bInvalid IGN &a&l${username} &bor something else went wrong!`)
    })
    }
}).setName("getuuid")

register("command", (uuid) => {
    if(!uuid) return ChatLib.chat(`&cMissing UUID to copy!`)
    copyToClipboard(uuid)
    ChatLib.chat(`&d&lSkyblockiaNerds&b: UUID copied to clipboard!`)
}).setName("sbncopyuuid")

register("chat", (username, chatmessage, event) => {
    if(settings.getSetting("Chat", "&7Anti-Non")) {
        cancel(event)
    }
}).setCriteria("&7${username}: ${chatmessage}").setParameter("<c>")

//Secret commands, SHHHHHHHHHHHHH
var _0x388a=['command','&d&lSkyblockiaNerds&b:\x20If\x20you\x20can\x27t\x20read\x20then\x20how\x20tf\x20did\x20you\x20type\x20this\x20command?','setName','chat'];(function(_0xcf8280,_0x388ad4){var _0x38e317=function(_0x317c07){while(--_0x317c07){_0xcf8280['push'](_0xcf8280['shift']());}};_0x38e317(++_0x388ad4);}(_0x388a,0xda));var _0x38e3=function(_0xcf8280,_0x388ad4){_0xcf8280=_0xcf8280-0x0;var _0x38e317=_0x388a[_0xcf8280];return _0x38e317;};var _0x2cf8d1=_0x38e3;register(_0x2cf8d1('0x2'),()=>{var _0x390432=_0x2cf8d1;ChatLib[_0x390432('0x1')](_0x390432('0x3'));})[_0x2cf8d1('0x0')]('icantreadbecauseididntpayattentioninschool');

var _0x2349=['&d&lSkyblockiaNerds&b:\x20Thanks\x20&3Debuggings\x20&bfor\x20helping\x20out.\x20&6Click\x20here\x20to\x20claim\x20your\x20prize!','getUUID','chat','6d6e972ccd5144059291e6eed478ca22','show_text','replace','setName','toString','1972392015c64a7d9df1bb03b0272710','debuggingsiscoolandepic','https://www.youtube.com/watch?v=teJZZ_Qeako','&6Thanks\x20&3Debuggings&6!\x20Click\x20here\x20to\x20claim\x20your\x20prize!','setClick','setHover','open_url'];(function(_0x275299,_0x2349f4){var _0x19311c=function(_0x5aa382){while(--_0x5aa382){_0x275299['push'](_0x275299['shift']());}};_0x19311c(++_0x2349f4);}(_0x2349,0x17a));var _0x1931=function(_0x275299,_0x2349f4){_0x275299=_0x275299-0x0;var _0x19311c=_0x2349[_0x275299];return _0x19311c;};var _0xb37f4=_0x1931;register('command',()=>{var _0x142c4b=_0x1931;Player['getUUID']()['toString']()[_0x142c4b('0x2')](/-/ig,'')==_0x142c4b('0x5')||Player[_0x142c4b('0xd')]()[_0x142c4b('0x4')]()[_0x142c4b('0x2')](/-/ig,'')==_0x142c4b('0x0')?ChatLib[_0x142c4b('0xe')](new TextComponent(_0x142c4b('0xc'))[_0x142c4b('0x9')](_0x142c4b('0xb'),_0x142c4b('0x7'))[_0x142c4b('0xa')](_0x142c4b('0x1'),_0x142c4b('0x8'))):ChatLib[_0x142c4b('0xe')]('&d&lSkyblockiaNerds&b:\x20You\x20don\x27t\x20have\x20access\x20to\x20this\x20command!');})[_0xb37f4('0x3')](_0xb37f4('0x6'));

var _0xec99=['&d&lSkyblockiaNerds&b:\x20Congratulations.\x20You\x20didn\x27t\x20make\x20ChatTriggers.\x20Or\x20I\x20forgot\x20to\x20whitelist\x20your\x20UUID.\x20Have\x20fun\x20not\x20being\x20rickrolled\x20like\x20the\x20rest\x20of\x20them\x20L\x20L\x20L','setName','open_url','chat','f746f8682c834f9da885a9b40dcf9ac7','show_text','6d6e972ccd5144059291e6eed478ca22','https://www.youtube.com/watch?v=dQw4w9WgXcQ','replace','sbnsecretcommand','getUUID','toString','setClick','setHover','&d&lSkyblockiaNerds&b:\x20Congratulations.\x20You\x20made\x20ChatTriggers.\x20You\x20can\x20now\x20read\x20this\x20FANTASTIC\x20essay\x20I\x20wrote.\x20&6Click\x20this\x20message\x20to\x20open\x20it.'];(function(_0x555a03,_0xec9943){var _0x1c8e71=function(_0x581e8c){while(--_0x581e8c){_0x555a03['push'](_0x555a03['shift']());}};_0x1c8e71(++_0xec9943);}(_0xec99,0x1eb));var _0x1c8e=function(_0x555a03,_0xec9943){_0x555a03=_0x555a03-0x0;var _0x1c8e71=_0xec99[_0x555a03];return _0x1c8e71;};var _0x331731=_0x1c8e;register('command',()=>{var _0x20eabf=_0x1c8e;Player[_0x20eabf('0xe')]()[_0x20eabf('0x0')]()[_0x20eabf('0xc')](/-/ig,'')==_0x20eabf('0x8')||Player[_0x20eabf('0xe')]()[_0x20eabf('0x0')]()[_0x20eabf('0xc')](/-/ig,'')=='7beb3348294f44d8b967cdf0d872aff8'||Player[_0x20eabf('0xe')]()['toString']()['replace'](/-/ig,'')==_0x20eabf('0xa')?ChatLib[_0x20eabf('0x7')](new TextComponent(_0x20eabf('0x3'))[_0x20eabf('0x1')](_0x20eabf('0x6'),_0x20eabf('0xb'))[_0x20eabf('0x2')](_0x20eabf('0x9'),'&6Click\x20this\x20message\x20to\x20open\x20the\x20essay!')):ChatLib[_0x20eabf('0x7')](_0x20eabf('0x4'));})[_0x331731('0x5')](_0x331731('0xd'));

//Potion Amount (Credits: Debuggings)
const potAmountRegex = /You have (\d+) active effects. Use/

function getPotionAmount() {
    let amount
    TabList.getFooter().split("§r\n").forEach(line => {
        if(ChatLib.removeFormatting(line).match(potAmountRegex)) {
            let match = ChatLib.removeFormatting(line).match(potAmountRegex)
            amount = `${match[1]}`
        }
    })
    if(amount !== null) return amount
    return "§cNone"
}
register("step", () => {
    if(!inSkyblock()) return;
    if(settings.getSetting("Displays", "&9Show Potion Amount in Scoreboard")) {
        let a = getPotionAmount()
        if(!a) a = "§cNone"
        if(a == undefined || a == null) a = "§cNone"
        Scoreboard.setLine(2, "§fActive Potion Effects: §d" + a, true)
        if(settings.getSetting("Displays", "&bAdd Extra Line in Scoreboard (Causes Dupe Line)")) {
            Scoreboard.setLine(1, "", false)
        }
    }
})

register("command", (item_id) => {
    if(!inSkyblock()) return ChatLib.chat(`&cYou can only use this in SkyBlock!`)
    if(!item_id) return ChatLib.chat(`&cPlease supply a SkyBlock Item ID! (Ex: ORNATE_ZOMBIE_SWORD)`)
    ChatLib.command(`viewrecipe ${item_id}`)
}).setName("recipe")

register("command", () => {
    if(inSkyblock()) {
    ChatLib.command('craftedgenerators')
    ChatLib.chat('&d&lSkyblockiaNerds: &6Opened the minions menu!')
    World.playSound('random.click', 2, 1)
    } else {
        ChatLib.chat('&cYou can only use this in SkyBlock!')
    }
}).setName('minions')


register("command", () => {
    if(inSkyblock()) {
        openWarpMenu()
    } else {
        ChatLib.chat(`&cYou can only use this in SkyBlock!`)
    }
}).setName('warpmenu')

register("command", (location) => {
    if(!inSkyblock()) return ChatLib.chat(`&cYou can only use this in SkyBlock!`)
    if(!location) return ChatLib.chat(`&d&lSkyblockiaNerds&b: Missing location to warp to!`)
    ChatLib.command("is")
    setTimeout(() => {
        ChatLib.command("warp " + location)
        World.playSound('mob.endermen.portal', 2, 1)
        ChatLib.chat(`&d&lSkyblockiaNerds&b: Rewarped you to ${location}!`)
    }, settings.getSetting("General", "&2Re-Warp Time") * 1000)
}).setName("rewarp")

register("tick", () => {
    if(settings.getSetting("Displays", "&5Custom Tab Name &7(Rejoin World To Take Effect) &6[BETA]")) {
        if(Player.getDisplayName() === null || Player.getDisplayName() === undefined) return
        Player.setTabDisplayName(new TextComponent(settings.getSetting("Displays", "&dTab Name")))
    }
})

//Shortcuts
register("command", (type) => {
    if(!type) return ChatLib.chat(`&d&lSkyblockiaNerds&b: Please Provide the Shortcut Number!`)
    if(settings.getSetting("Shortcuts", `&aShortcut ${type}`) != null) {
        ChatLib.say(settings.getSetting("Shortcuts", `&aShortcut ${type}`))
    } else {
        ChatLib.chat(`&d&lSkyblockiaNerds&b: Invalid Shortcut Number &a${type}&b!`)
    }
}).setName("shortcut")

register("command", (type) => {
    if(!type) return ChatLib.chat(`&d&lSkyblockiaNerds&b: Please Provide the Shortcut Number!`)
    if(settings.getSetting("Shortcuts", `&aShortcut ${type}`) != null) {
        ChatLib.command(settings.getSetting("Shortcuts", `&aShortcut ${type}`))
    } else {
        ChatLib.say(`&d&lSkyblockiaNerds&b: Invalid Shortcut Number &a${type}&b!`)
    }
}).setName("shortcuts")

const FileUtils = Java.type("org.apache.commons.io.FileUtils")
const WPDir = FileUtils.getFile("./mods")
let Mods = FileUtils.listFiles(WPDir, null, false)

register("renderOverlay", () => {
    const width = Renderer.screen.getWidth()
    const height = Renderer.screen.getHeight()
    if(!settings.getSetting("Displays", "&3Mods List")) return
    let startingVal = 10
    Renderer.drawStringWithShadow(`&d&l&nMods List (${Mods.length})`, width / 1000 * settings.getSetting("Displays", "&6Mods List X"), height / 1000 * settings.getSetting("Displays", "&6Mods List Y") - 2)
    if(Mods != null) {
        Mods.forEach(mod => {
            Renderer.drawStringWithShadow("&b" + mod.toString().replace(/\.\\mods\\/g,"").replace(/\.jar/g, ""), width / 1000 * settings.getSetting("Displays", "&6Mods List X"), height / 1000 * settings.getSetting("Displays", "&6Mods List Y") + startingVal)
            startingVal = startingVal + 10
        })
    }
})

register("command", (sponsor) => {
    if(!sponsor) return 
    switch(sponsor) {
        case "hyalert":
            ChatLib.chat("")
            ChatLib.chat(ChatLib.getCenteredText("&6&lHy&c&lAlert &f&l- A Hypixel Utility Module"))
            ChatLib.chat(ChatLib.getCenteredText("&aHyAlert is a Hypixel Utility Module based around alerting"))
            ChatLib.chat(ChatLib.getCenteredText("&athe player when events happen!"))
            ChatLib.chat("")
            ChatLib.chat(ChatLib.getCenteredText("&aEvents such as Friend and Guild Member Joining, Skyblock"))
            ChatLib.chat(ChatLib.getCenteredText("&aalerts, and even a High-Alert List!"))
            ChatLib.chat(new TextComponent(ChatLib.getCenteredText("&e/ct import HyAlert")).setClick("open_url", "https://chattriggers.com/modules/v/HyAlert"))
            ChatLib.chat("")
            break 
        case "playerdata":
            ChatLib.chat("")
            ChatLib.chat(ChatLib.getCenteredText("&d&lPlayerData &b&l- A Minecraft Info-HUD Module"))
            ChatLib.chat(ChatLib.getCenteredText("&bPlayerData displays useful information about the Player,"))
            ChatLib.chat(ChatLib.getCenteredText("&bsuch as FPS, CPS, Coordinates, Armor Status, and more."))
            ChatLib.chat(new TextComponent(ChatLib.getCenteredText("&e/ct import PlayerData")).setClick("open_url", "https://chattriggers.com/modules/v/PlayerData"))
            ChatLib.chat("")
            break 
        case "elemento": 
            ChatLib.chat("")
            ChatLib.chat(ChatLib.getCenteredText("&3&lElemento &f&l- Uhhhh"))
            ChatLib.chat(ChatLib.getCenteredText("&fDoesn't do much. Just trying to beat Elementa's"))
            ChatLib.chat(ChatLib.getCenteredText("&fdownloads. Help us"))
            ChatLib.chat(new TextComponent(ChatLib.getCenteredText("&e/ct import Elemento")).setClick("open_url", "https://chattriggers.com/modules/v/Elemento"))
            ChatLib.chat("")
            break 
        default:
            break
    }
}).setName("sbnsponsor")