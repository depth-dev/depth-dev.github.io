import { Setting, SettingsObject } from "SettingsManager/SettingsManager"


const settings = new SettingsObject(
    "SkyblockiaNerds",
    [
        {
            name: "General",
            settings: [
                new Setting.Button("", "&eSkyblock", () => {}),
                new Setting.Slider("&2Re-Warp Time", 2, 1, 5), //SLIDER
                new Setting.Button("&cReset Settings", "&eClick here", () => {
                    ChatLib.simulateChat("&d&lSkyblockiaNerds&b: Reset your settings!")
                }),
                new Setting.Button("", "", () => {}),
                new Setting.Button("&cCredits:", "", () => {}),
                new Setting.Button("&bmisterdepth", "&dPrimary Development", () => {
                    setTimeout(() => {
                        World.playSound("fireworks.launch", 2, 1),
                        Thread.sleep(1500)
                        World.playSound("fireworks.largeBlast", 2, 1)
                        Thread.sleep(250)
                        World.playSound("fireworks.twinkle", 2, 1)
                    }, 0)
                }),
                new Setting.Button("&aBryaben", "&9Beta Testing", () => {
                    World.playSound("mob.blaze.hit", 2, 1)
                }),
                new Setting.Button("&6DJtheRedstoner", "&2Assistance with the code", () => {
                    World.playSound("tile.piston.out", 2, 1)
                }),
                new Setting.Button("&3Debuggings", "&7Idea of Anti-Non + Assistance with Code/Potion Amount", () => {
                    World.playSound("mob.wither.death", 2, 1)
                }),
                new Setting.Button("&5Squagward", "&6Inspiration for Miniboss Alerts", () => {
                    World.playSound("mob.wolf.bark", 2, 1)
                }),
                new Setting.Button("&1Vals", "&eHelp with checking SkyBlock Locations", () => {
                    World.playSound("random.burp", 2, 1)
                }),
                new Setting.Button("&ejhamster", "&fHelp with Mods List", () => {
                    World.playSound("game.potion.smash", 2, 1)
                }),
                new Setting.Button("", "", () => {}),
                new Setting.Button("", "", () => {}),
                new Setting.Button("", "&eMade by NVP (Not Very Professional)", () => {
                    new Message(
                        new TextComponent("&6NVP &bis an in-progress Development Team that makes CT modules, discord bots, and more!\n"),
                        new TextComponent("&bInterested? Community discord coming soon!")
                    ).chat()
                })
            ]
        },
        {
            name: "Chat",
            settings: [
                new Setting.Toggle("&7Anti-Non", false),
                new Setting.Toggle("&6Prevent \"&cYou cannot leave this area!&6\" messages", false),
                new Setting.Toggle("&9Hide \"&6joined the lobby!&9\" messages", false),
                new Setting.Toggle("&eHide &bMystery Box &emessages", false),
                new Setting.Toggle("&cHide Watchdog Announcements", false),
                new Setting.Toggle("&bHide CoopChat Outside of Skyblock", false),
                new Setting.Toggle("&aAntiSBJoin", false),

            ]
        },
        {
            name: "Displays",
            settings: [
                new Setting.Button("", "&eGeneral", () => {}),
                new Setting.Toggle("&5Custom Tab Name &7(Rejoin World To Take Effect) &6[BETA]", false),
                new Setting.TextInput("&dTab Name", `&6${Player.getName().toString()}`),
                new Setting.Button("", "&eInformation", () => {}),
                new Setting.Toggle("&dShow Coordinates on Screen", false),
                new Setting.Toggle("&2Dark Background Behind Coordinates", false),
                new Setting.Toggle("&aAdjust Box Based on Coordinates Length &6[BETA]", false),
                new Setting.Slider("&bCoordinate Decimal Count", 1, 0, 5),
                new Setting.Toggle("&3Mods List", false),
                new Setting.Slider("&6Mods List X", 5, 0, 1000),
                new Setting.Slider("&6Mods List Y", 250, 0, 1000),
                new Setting.Button("", "", () => {}),
                new Setting.Button("", "&eHUD", () => {}),
                new Setting.Toggle("&9Show Potion Amount in Scoreboard", false),
                new Setting.Toggle("&bAdd Extra Line in Scoreboard (Causes Dupe Line)", false),
            ]
        },
        {
            name: "Alerts",
            settings: [
                new Setting.Button("", "&eMega-Alerts", () => {}),
                new Setting.StringSelector("&cMega-Alert Mode", 2, [
                    "Title (Big)",
                    "Title (Small)",
                    "Chat",
                ]),
                new Setting.Toggle("&cMega-Alerts", false),
                new Setting.Button("", "&eSkyblock Alerts", () => {}),
                new Setting.Toggle("&aIsland Visitor Alerts", true),
                new Setting.Toggle("&eAuction Bid Alerts", true),
                new Setting.Toggle("&6Large Amount of Coins Alert", true),
                new Setting.Toggle("&4Low Health Alert &6[BETA]", false),
                new Setting.Button("", "&eSkyblock Dungeon Alerts", () => {}),
                new Setting.Toggle("&bAbility Ready Alerts", false),
            ]
        },
        {
            name: "Chat Customizer",
            settings: [
                new Setting.Button("", "&cWARNING: &eThese are strict on color codes!", () => {}),
                new Setting.Button("", "&ePM Message Customizer", () => {}),
                new Setting.Toggle("&5Custom PMs", false),
                new Setting.TextInput("&dFrom &fMessage", "&dF &7>"),
                new Setting.TextInput("&dTo &fMessage", "&dT &7>"),
                new Setting.Button("", "&eJoin/Leave Message Customizer", () => {}),
                new Setting.Toggle("&aCustom Join/Leave Messages", false),
                new Setting.TextInput("&2Guild", "&2G >"),
                new Setting.TextInput("&aFriends", "&aF >"),
                new Setting.Button("", "&eCustom Chat Prefixes"),
                new Setting.Toggle("&3Custom Chat Prefixes", false),
                new Setting.TextInput("&9Party Chat Prefix", "&9PC &8>"),
                new Setting.TextInput("&2Guild Chat Prefix", "&2GC >"),
                new Setting.TextInput("&bCoop-Chat Prefix", "&bCC >"),
            ]
        },
        {
            name: "Emotes",
            settings: [
                new Setting.Button("", "&eTwitch Emotes", () => {}),
                new Setting.Toggle("&2Emote Display", false),
                new Setting.StringSelector("&2Emote Selected", 0, [
                    "Pepega",
                    "PogChamp"
                ]),
                new Setting.Slider("&aEmote Display X", 100, 0, 1000),
                new Setting.Slider("&aEmote Display Y", 100, 0, 1000),
                new Setting.Slider("&aEmote Display Size", 100, 0, 400),
            ]
        },
        {
            name: "Shortcuts",
            settings: [
                new Setting.Button("", "&eShortcuts (Only 5 Spots!)", () => {}),
                new Setting.Button("", "", () => {}),
                new Setting.TextInput("&aShortcut 1", "/lobby"),
                new Setting.Button("", "", () => {}),
                new Setting.TextInput("&aShortcut 2", "/party list"),
                new Setting.Button("", "", () => {}),
                new Setting.TextInput("&aShortcut 3", "/play sb"),
                new Setting.Button("", "", () => {}),
                new Setting.TextInput("&aShortcut 4", "/help"),
                new Setting.Button("", "", () => {}),
                new Setting.TextInput("&aShortcut 5", "/friend add ChatTriggers")
            ]
        }
    ]
);

function resetS() {
    settings.reset()
    settings.load()
}

settings.setCommand("sbnsettings").setSize(450, 310)

export { settings }

