//Imports is Super Cool
import { Setting, SettingsObject } from "SettingsManager/SettingsManager"
import { inSkyblock } from "./utils/inSkyblock.js"
import { failHelp, failTic, failBlaze, failRiddle } from "./utils/dungeonFailure.js"
import { onIsland, inPark } from "./utils/locationChecker.js"
import { openWarpMenu } from "./utils/warpMenu.js"
import request from "request/index";
import PVObject from "PersistentData"
const prefix = "&d&lSkyblockiaNerds"

//Defining Functions is Super Cool
const getjson = function(url) {
    return request({
        url: url,
        headers: {
            'User-Agent': 'Mozilla/5.0 (ChatTriggers)'
        },
        json: true
    });
}
copyToClipboard = text => {
    clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
    output = new StringSelection(text);
    
    try {
      clipboard.setContents(output, output);
      print("Copied text to clipboard.")
    } catch (err) {
      print(err)
    }
}



const settings = new SettingsObject(
    "SkyblockiaNerds",
    [
        {
            name: "General",
            settings: [
                new Setting.Toggle("&aAntiSBJoin", true),
                new Setting.Toggle("&bSkyblock Alerts", true),
                new Setting.Toggle("&6Large Amount of Coins Alert", true),
                new Setting.Slider("&2Re-Warp Time", 2, 1, 5), //SLIDER
                new Setting.Button("", "", () => {}),
                new Setting.Button("", "", () => {}),
                new Setting.Button("&cCredits:", "", () => {}),
                new Setting.Button("&bmisterdepth", "&dPrimary Development", () => {}),
                new Setting.Button("&aBryaben", "&9Beta Testing", () => {}),
                new Setting.Button("&6DJtheRedstoner", "&2Assistance with the code", () => {}),
                new Setting.Button("&3Debuggings", "&7Idea of Anti-Non + Assistance with Code/Potion Amount", () => {}),
            ]
        },
        {
            name: "Chat",
            settings: [
                new Setting.Toggle("&7Anti-Non", false),
                new Setting.Toggle("&6Prevent \"&cYou cannot leave this area!&6\" messages", false),
            ]
        },
        {
            name: "Displays",
            settings: [
                new Setting.Button("", "&eCoordinates", () => {}),
                new Setting.Toggle("&dShow Coordinates on Screen", false),
                new Setting.Toggle("&2Dark Background Behind Coordinates", false),
                new Setting.Slider("&bCoordinate Decimal Count", 1, 0, 5),
                new Setting.Button("", "", () => {}),
                new Setting.Button("", "&eHUD", () => {}),
                new Setting.Toggle("&9Show Potion Amount in Scoreboard", false),
                new Setting.Toggle("&bAdd Extra Line in Scoreboard (Causes Dupe Line)", false),
            ]
        },
        {
            name: "Alerts",
            settings: [
                new Setting.Button("", "&eMega-Alerts", () => {}),
                new Setting.StringSelector("&cMega-Alert Mode", 2, [
                    "Title (Big)",
                    "Title (Small)",
                    "Chat",
                ]),
                new Setting.Toggle("&cMega-Alerts", false),
                new Setting.Button("", "", () => {}),
            ]
        }
    ]
);
settings.setCommand("sbnsettings").setSize(420, 250)

Setting.register(settings);


//Keybinds
const sbMenuKeybind = new KeyBind("Open SBMenu", Keyboard.KEY_NONE, "SkyblockiaNerds")
const wardrobeKeybind = new KeyBind("Open Wardrobe", Keyboard.KEY_NONE, "SkyblockiaNerds")
const craftKeybind = new KeyBind("Open Crafting Menu", Keyboard.KEY_NONE, "SkyblockiaNerds")
const ecKeybind = new KeyBind("Open EnderChest", Keyboard.KEY_NONE, "SkyblockiaNerds")
const settingsKeybind = new KeyBind("Open Settings GUI", Keyboard.KEY_NONE, "SkyblockiaNerds")
const warpMenuKeybind = new KeyBind("Warp Menu", Keyboard.KEY_NONE, "SkyblockiaNerds")


register("tick", () => {
    if(settingsKeybind.isPressed()) settings.open()
    if(warpMenuKeybind.isPressed()) openWarpMenu()
    if(!inSkyblock()) return 
    if(sbMenuKeybind.isPressed()) ChatLib.command("sbmenu")
    if(wardrobeKeybind.isPressed()) ChatLib.command("wardrobe")
    if(craftKeybind.isPressed()) ChatLib.command("craft")
    if(ecKeybind.isPressed()) ChatLib.command("enderchest")
})




//The other garbage
const Toolkit = Java.type("java.awt.Toolkit");
const StringSelection = Java.type("java.awt.datatransfer.StringSelection");

const GlStateManager = Java.type("net.minecraft.client.renderer.GlStateManager");

const EntityArmorStand = Java.type("net.minecraft.entity.item.EntityArmorStand");
const Minecraft = Client.getMinecraft();
let commandToggled

register("command", (pageNum) => {
    if(!pageNum) {
        ChatLib.chat('&b&m&l-----------&d&lSkyblockiaNerds Commands&b&m&l----------------\n' + 
        '&b- /dh &a(Warp to dungeon hub)\n' +
        '&b- /ec &a(Open enderchest)\n' +
        '&b- /crd &a(Crazy Rare Drop!)\n' + 
        '&b- /sbnsettings &a(Shows you your settings!)\n' +
        '&b- /minions &a(Shows you your crafted minions!)\n' +
        '&b- /viewplancke &a(Plancke link for user!)\n' +
    '&2Page 1/2')
    ChatLib.chat("&b&m" + ChatLib.getChatBreak("-"))
    } else {
    switch(pageNum) {
        case "1":
            ChatLib.chat('&b&m&l-----------&d&lSkyblockiaNerds Commands&b&m&l----------------\n' + 
                '&b- /dh &a(Warp to dungeon hub)\n' +
                '&b- /ec &a(Open enderchest)\n' +
                '&b- /crd &a(Crazy Rare Drop!)\n' + 
                '&b- /sbnsettings &a(Shows you your settings!)\n' +
                '&b- /minions &a(Shows you your crafted minions!)\n' +
                '&b- /viewplancke &a(Shows you the plancke url for a given username!)\n' +
            '&2Page 1/2')
            ChatLib.chat("&b&m" + ChatLib.getChatBreak("-"))
            break
        case "2":
            ChatLib.chat('&b&m&l-----------&d&lSkyblockiaNerds Commands&b&m&l----------------\n' +
                '&b- /failhelp &a(Shows you commands for the Dungeon Failures!)\n' +
                '&b- /warpmenu &a(Get some easy-click warp commands!)\n' +
                '&b- /rewarp &a(Swap a warp location quickly!)\n' +
                '&b- /getuuid &a(Get the UUID of a given player!)\n' +
                '&b- /sbnerds info &a(Info of the module!)\n' +
                '&b- /sbnclipboard &a(Have a second clipboard!)\n' +
                '&b More coming soon!\n' +
            '&2Page 2/2')
            ChatLib.chat("&b&m" + ChatLib.getChatBreak("-"))
            break 
        case "settings":
            settings.open()
            break
        case "downloads":
            getjson("https://www.chattriggers.com/api/modules/SkyblockiaNerds").then(response => {
                let downloads = response["downloads"]
                ChatLib.chat(`&d&lSkyblockiaNerds&b: This module has &a&l${downloads} &bdownloads!`)
            }).catch(err => {
                print(err)
                ChatLib.chat(`&d&lSkyblockiaNerds&b: An error occurred when fetching the downloads of this module!`)
            })
            break
        case "info":
            ChatLib.chat('&b&m&l-------------&d&lSkyblockiaNerds Info&b&m------------------\n' +
            '&bWhat is SkyblockiaNerds?\n' +
            '&a -SkyblockiaNerds is a Skyblock + General Hypixel Utility Module for ChatTriggers.\n' +
            '&a -While is is meant for Skyblock, some features (such as Coordinates) can be used anywhere!\n' +
            '&bWhat features does it have?\n' +
            '&a -It has Alerts for when you go into a mega, when you have a large amount of coins in your purse, and even more!\n' +
            '&a -There are also Non-SB Related Utilities (despite the name being SkyblockiaNerds) including coordinates and more!\n' +
            '&bDo I have the latest version?\n' +
            '&a -All public releases made will be auto-updated with chattriggers, and Betas are private (meaning they are only given to some people!)')
            ChatLib.chat("&b&m&l-----------------------------------------------")
            break 
        default:
            ChatLib.chat('&d&lSkyblockiaNerds: &2Invalid number! Please insert a page (1-2)')
            break
    }
}
}).setName('sbnerds')

register("command", () => {
    if(inSkyblock()) {
        ChatLib.command('enderchest')
        ChatLib.chat(`&d&lSkyblockiaNerds: &2Opened your EnderChest!`)
    } else {
        ChatLib.chat('&cYou can only use this in SkyBlock!')
    }
}).setName('ec')

register("command", () => {
    if(inSkyblock()) {
        ChatLib.command('warp dungeon_hub')
        ChatLib.chat(`&d&lSkyblockiaNerds: &6Warped you to dungeon hub!`)
        World.playSound('mob.endermen.portal', 2, 1)
    } else {
        ChatLib.chat('&cYou can only use this in SkyBlock!')
    }
}).setName('dh')

register("command", (...args) => {
    const itemThing = args.slice(1).join(' ')
    if(!itemThing) {
        ChatLib.chat(`&cPlease provide an item and a rarity! (Example: /crd epic Overflux Capacitor)`)
    } else {
        switch(args[0]) {
            case "common":
                ChatLib.chat(`&d&lCRAZY RARE DROP! &7(&f${itemThing}&7) &b(+98% Magic Find)`)
                break
            case "uncommon":
                ChatLib.chat(`&d&lCRAZY RARE DROP! &7(&a${itemThing}&7) &b(+98% Magic Find)`)
                break 
            case "rare":
                ChatLib.chat(`&d&lCRAZY RARE DROP! &7(&9${itemThing}&7) &b(+98% Magic Find)`)
                break
            case "epic":
                ChatLib.chat(`&d&lCRAZY RARE DROP! &7(&5${itemThing}&7) &b(+98% Magic Find)`)
                break 
            case "legendary":
                ChatLib.chat(`&d&lCRAZY RARE DROP! &7(&6${itemThing}&7) &b(+98% Magic Find)`)
                break 
            default:
                ChatLib.chat(`&cYou can only have &fcommon&c, &auncommon&c, &9rare&c, &5epic&c, or &6legendary&c as a rarity!`)
        }
     }
}).setName('crd')

register("chat", (coopMate, event) => {
    commandToggled = settings.getSetting("General", "&aAntiSBJoin");
    if(!commandToggled) return
    cancel(event)
}).setCriteria('&b${coopMate} joined SkyBlock.&r').setParameter("<c>")

register("chat", (coopMate, event) => {
    commandToggled = settings.getSetting("General", "&aAntiSBJoin");
    if(!commandToggled) return
    cancel(event)
}).setCriteria('&b${coopMate} left SkyBlock.&r').setParameter("<c>")

register("chat", (visiter, event) => {
    commandToggled = settings.getSetting("General", "&bSkyblock Alerts");
    if(!commandToggled) return
    ChatLib.chat(`&d&lSkyblockiaNerds: &b${visiter} &bjoined your island!`)
    World.playSound('random.orb', 2, 1)
    cancel(event)
}).setCriteria('&b[SkyBlock] &r${visiter} &r&eis visiting &r&aYour Island&r&e!&r').setParameter('<c>')

register("chat", (bidder, coins, item) => {
    commandToggled = settings.getSetting("General", "&bSkyblock Alerts");
    if(!commandToggled) return
    //World.playSound('random.orb', 2, 1)
}).setCriteria('&r&6[Auction] ${bidder} &ebought ${item} &efor ${coins} &lCLICK&r&r').setParameter('<c>')

register("command", () => {
    if(inSkyblock()) {
    ChatLib.command('craftedgenerators')
    ChatLib.chat('&d&lSkyblockiaNerds: &6Opened the minions menu!')
    World.playSound('random.click', 2, 1)
    } else {
        ChatLib.chat('&cYou can only use this in SkyBlock!')
    }
}).setName('minions')

register("chat", (megaID) => {
    commandToggled = settings.getSetting("Alerts", "&cMega-Alerts");
    alertMode = settings.getSetting("Alerts", "&cMega-Alert Mode");
    if(!commandToggled) return
    if(!inSkyblock()) return
    switch(alertMode) {
        case "Title (Big)":
            setTimeout(() => {
                Client.showTitle("&bYou are entering a mega!", "", 0, 30, 0)
                World.playSound('random.orb', 2, 1)
             }, 1500)
            break
        case "Title (Small)":
            setTimeout(() => {
                Client.showTitle("", "&bYou are entering a mega!", 0, 30, 0)
                World.playSound('random.orb', 2, 1)
             }, 1500)
            break
        case "Chat":
            setTimeout(() => {
                ChatLib.chat('&d&lSkyblockiaNerds: &bYou are entering a mega! Be careful!')
                World.playSound('random.orb', 2, 1)
             }, 1500)
            break
        default:
            break
    }
}).setCriteria('&7Sending to server mega${*}').setParameter('<c>')

register("command", (name) => {
    if(!name) return ChatLib.chat('&cPlease input a username!')
    getjson(`https://api.mojang.com/users/profiles/minecraft/${name}`).then(response => {
        var uuid = response["id"];
            ChatLib.chat(new TextComponent(`&d&lSkyblockiaNerds: &a&l${name}'s &bPlancke`).setClick("open_url", `https://plancke.io/hypixel/player/stats/${name}`).setHover("show_text", "&bClick here for the plancke of this user!"))
    }).catch(error => {
        print(error)
        ChatLib.chat(`&d&lSkyblockiaNerds: &bInvalid IGN &a&l${name} &bor something else went wrong!`)
    })
}).setName('viewplancke')

register("command", () => {
    if(inSkyblock()) {
        openWarpMenu()
    } else {
        ChatLib.chat(`&cYou can only use this in SkyBlock!`)
    }
}).setName('warpmenu')

register("command", (location) => {
    if(!inSkyblock()) return ChatLib.chat(`&cYou can only use this in SkyBlock!`)
    if(!location) return ChatLib.chat(`&d&lSkyblockiaNerds&b: Missing location to warp to!`)
    ChatLib.command("is")
    setTimeout(() => {
        ChatLib.command("warp " + location)
        World.playSound('mob.endermen.portal', 2, 1)
        ChatLib.chat(`&d&lSkyblockiaNerds&b: Rewarped you to ${location}!`)
    }, settings.getSetting("General", "&2Re-Warp Time") * 1000)
}).setName("rewarp")

//DungeonFailure Commands
register("command", (helpWith) => {
    failHelp(helpWith)
}).setName("failhelp")

register("command", (username, userRank) => {
    failTic(username, userRank)
}).setName("failtic")

register("command", (username, userRank) => {
    failBlaze(username, userRank)
}).setName("failblaze")

register("command", (username, userRank, riddleName) => {
    failRiddle(username, userRank, riddleName)
}).setName("failriddle")

register("worldLoad", () => {
    if(settings.getSetting("General", "&6Large Amount of Coins Alert")) {
        setTimeout(() => {
            if(inSkyblock() && !onIsland()) {
                Scoreboard.getLines(false).forEach(line => {
                    if(String(line).includes("Piggy") || String(line).includes("Purse")) {
                        let amount = String(line).split(": §6").slice(1)
                        let aCoins = amount[0].replace(",", "")
                        let theCoins = parseFloat(aCoins)
                        if(theCoins > 20000) {
                            World.playSound("random.orb", 2, 1)
                            ChatLib.chat(`&d&lSkyblockiaNerds&b: You have a large amount of coins on you (&6${amount[0]}&b!) Be careful!`)
                        }
                    }
                })
            }
        }, 1000)
    }
})


register("command", (username) => {
    if(!username) {
        let playerUUID = Player.getUUID().toString().replace(/-/ig, "")
        ChatLib.chat(new TextComponent(`&d&lSkyblockiaNerds&b: Click to copy your UUID!`).setClick("run_command", `/sbncopyuuid ${playerUUID}`).setHover("show_text", "&6Click to copy your UUID!"))

    } else {
        getjson(`https://api.mojang.com/users/profiles/minecraft/${username}`).then(response => {
        var uuid = response["id"];
            ChatLib.chat(new TextComponent(`&d&lSkyblockiaNerds&b: Click here to copy ${username}&b's UUID!`).setClick("run_command", `/sbncopyuuid ${uuid}`).setHover("show_text", `&6Click to copy ${username}'s UUID!`))
    }).catch(error => {
        print(error)
        ChatLib.chat(`&d&lSkyblockiaNerds: &bInvalid IGN &a&l${username} &bor something else went wrong!`)
    })
    }
}).setName("getuuid")

register("command", (uuid) => {
    if(!uuid) return ChatLib.chat(`&cMissing UUID to copy!`)
    copyToClipboard(uuid)
    ChatLib.chat(`&d&lSkyblockiaNerds&b: UUID copied to clipboard!`)
}).setName("sbncopyuuid")

register("chat", (username, chatmessage, event) => {
    if(settings.getSetting("Chat", "&7Anti-Non")) {
        cancel(event)
    }
}).setCriteria("&7${username}: ${chatmessage}").setParameter("<c>")


//Player Coordinates
let playerX
let playerY
let playerZ

register("tick", () => {
    playerX = Player.getX().toFixed(settings.getSetting("Displays", "&bCoordinate Decimal Count"))
    playerY = Player.getY().toFixed(settings.getSetting("Displays", "&bCoordinate Decimal Count"))
    playerZ = Player.getZ().toFixed(settings.getSetting("Displays", "&bCoordinate Decimal Count"))
})

register("renderOverlay", renderOverlay)
let theColor = Renderer.color(0, 0, 0, 50)
function renderOverlay() {
    if(settings.getSetting("Displays", "&2Dark Background Behind Coordinates") && settings.getSetting("Displays", "&dShow Coordinates on Screen")) {
        Renderer.drawRect(theColor, 0, 0, 50 + settings.getSetting("Displays", "&bCoordinate Decimal Count") * 5 + 5, 40)
    }
    if(settings.getSetting("Displays", "&dShow Coordinates on Screen")) {
        Renderer.drawStringWithShadow(`&dX &7> &b${playerX}`, 5, 5)
        Renderer.drawStringWithShadow(`&dY &7> &b${playerY}`, 5, 15)
        Renderer.drawStringWithShadow(`&dZ &7> &b${playerZ}`, 5, 25)
    }
}


//Secret commands, SHHHHHHHHHHHHH
register("command", () => {
    ChatLib.chat(`&d&lSkyblockiaNerds&b: If you can't read then how tf did you type this command?`)
}).setName("icantreadbecauseididntpayattentioninschool")

register("command", () => {
    if(Player.getUUID().toString().replace(/-/ig, "") == "1972392015c64a7d9df1bb03b0272710" || Player.getUUID().toString().replace(/-/ig, "") == "6d6e972ccd5144059291e6eed478ca22") {
        ChatLib.chat(new TextComponent(`&d&lSkyblockiaNerds&b: Thanks &3Debuggings &bfor helping out. &6Click here to claim your prize!`).setClick("open_url", "https://www.youtube.com/watch?v=teJZZ_Qeako").setHover("show_text", "&6Thanks &3Debuggings&6! Click here to claim your prize!"))
    } else {
        ChatLib.chat(`&d&lSkyblockiaNerds&b: You don't have access to this command!`)
    }
}).setName("debuggingsiscoolandepic")

register("command", () => {
    if(Player.getUUID().toString().replace(/-/ig, "") == "f746f8682c834f9da885a9b40dcf9ac7" || Player.getUUID().toString().replace(/-/ig, "") == "7beb3348294f44d8b967cdf0d872aff8" || Player.getUUID().toString().replace(/-/ig, "") == "6d6e972ccd5144059291e6eed478ca22") {
        ChatLib.chat(new TextComponent("&d&lSkyblockiaNerds&b: Congratulations. You made ChatTriggers. You can now read this FANTASTIC essay I wrote. &6Click this message to open it.").setClick("open_url", "https://www.youtube.com/watch?v=dQw4w9WgXcQ").setHover("show_text", "&6Click this message to open the essay!"))
    } else {
        ChatLib.chat("&d&lSkyblockiaNerds&b: Congratulations. You didn't make ChatTriggers. Or I forgot to whitelist your UUID. Have fun not being rickrolled like the rest of them L L L")
    }
}).setName("sbnsecretcommand")

//Potion Amount (THANK YOU DEBUGGINGS)
const potAmountRegex = /You have (\d+) active effects. Use \"\/effects\" to see them!/;

function getPotionAmount() {
    let amount;
    TabList.getFooter().split("\n").forEach(line => {
        if(ChatLib.removeFormatting(line).match(potAmountRegex)) {
            let match = ChatLib.removeFormatting(line).match(potAmountRegex);
            amount = `${match[1]}`;
        }
    });
    if(amount !== null) return amount
    return "§cNone";
}
register("step", () => {
    if(!inSkyblock()) return;
    if(settings.getSetting("Displays", "&9Show Potion Amount in Scoreboard")) {
        let a = getPotionAmount()
        if(!a) a = "§cNone"
        if(a == undefined || a == null) a = "§cNone"
        Scoreboard.setLine(2, "§fActive Potion Effects: §d" + a, true)
        if(settings.getSetting("Displays", "&bAdd Extra Line in Scoreboard (Causes Dupe Line)")) {
            Scoreboard.setLine(1, "", false)
        }
    }
})

register("chat", (event) => {
    if(settings.getSetting("Chat", "&6Prevent \"&cYou cannot leave this area!&6\" messages")) {
        cancel(event)
    }
}).setCriteria("&r&cYou are not allowed to leave this area!&r").setParameter("<c>")

//Clipboard
const pvObject = new PVObject("SkyblockiaNerds", {
    sbnclipboard: "Your clipboard will go here!"
})

register("command", (...args) => {
    if(!args[0]) return ChatLib.chat(`&d&lSkyblockiaNerds&b: Please submit a valid function! Valid functions: &aCopy, Paste, List`)
    switch(args[0]) {
        case "list":
            ChatLib.chat(`&d&lSkyblockiaNerds&b: Your SBN Clipboard is &a${pvObject.sbnclipboard}&b!`)
            break 
        case "copy":
            let whatToCopy = args.slice(1).join(" ")
            if(!whatToCopy) return ChatLib.chat(`&d&lSkyblockiaNerds&b: Please provide something to copy!`)
            pvObject.sbnclipboard = whatToCopy
            ChatLib.chat(`&d&lSkyblockiaNerds&b: Copied text to your SBN Clipboard! Do &a/sbnclipboard paste &bto copy it to your computer clipboard!`)
            break 
        case "paste":
            copyToClipboard(pvObject.sbnclipboard)
            ChatLib.chat(`&d&lSkyblockiaNerds&b: Copied your SBN Clipboard to your computer clipboard!`)
            break 
        default:
            ChatLib.chat(`&d&lSkyblockiaNerds&b: Please submit a valid function! Valid functions: &aCopy, Paste, List`)
    }
}).setName("sbnclipboard")