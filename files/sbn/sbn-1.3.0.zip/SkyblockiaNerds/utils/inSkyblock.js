function inSkyblock() {
    if(ChatLib.removeFormatting(Scoreboard.getTitle()).includes("SKYBLOCK")) {
        return true
    } else {
        return false
    }
}

export { inSkyblock }