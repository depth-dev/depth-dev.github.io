function onIsland() {
    if(!(Scoreboard.getTitle().trim() != "" && Scoreboard.getLines().length > 0)) {
        return;
    }
    for(let i = 0; i < Scoreboard.getLines().length; i++) {
        let line = Scoreboard.getLines()[i]
        if(line.getName().includes('Your'))
            return true;
    }
    return false;
}

function inPark() {
    if(!(Scoreboard.getTitle().trim() != "" && Scoreboard.getLines().length > 0)) {
        return;
    }
    for(let i = 0; i < Scoreboard.getLines().length; i++) {
        let line = Scoreboard.getLines()[i]
        if(line.getName().includes('Birch Par'))
            return true;
    }
    return false;
}

export { onIsland, inPark }