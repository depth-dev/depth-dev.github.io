yo

everything in this pack was made by me

or like most of it

maybe not the lang part because i copied it from some default pack and changed the values

but other than that i made the music and drew the discs 

first time making pixel art so dont expect much

shoutout to preacherjackarie noxirose and whatazinger because they are really cool :)

enjoy